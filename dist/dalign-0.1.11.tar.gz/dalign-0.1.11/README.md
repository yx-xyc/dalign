```
Configuration Structure:
    dalign
    | - build
    | - dalign
    | | - __init__.py
    | | - data_verify.py
    | | - datetime.py
    | | - missing_value.py
    | | - utility.py
    | - dalign.egg-info
    | - dist
    | - examples
    | - tests
    | - build_deploy.sh
    | - LICSNSE
    | - README.md
    | - setup.py
```

This packages contains function to help to basic data pre-process, data exploration for numeric, categorical, and datetime variables. 